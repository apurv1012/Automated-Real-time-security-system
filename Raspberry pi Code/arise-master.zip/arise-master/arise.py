#!/usr/bin/python
# -*- coding: utf-8 -*-
import time
import random
import re
import os
#import curses
import cv2
import smtplib
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(32, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(22, GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setup(11, GPIO.OUT)   
GPIO.setup(18, GPIO.IN)    
GPIO.setup(16, GPIO.OUT)   

ROW         = [31,33,35,37]
COL      = [36,38,40]
print('################GPIO SET')
GPIO.setup(11, GPIO.LOW)
GPIO.setup(16, GPIO.LOW)
MATRIX = [  ['6','5','4'],                          
            ['3','2','1'],
            ['9','8','7'],
            ['','0','']     ]
print('################INITIAL SETUP SUCCESSFUL')
normalPassword = '111';
emergencyPassword = '555';
inputPassword = '0000'
passwordAuthentication = False
faceAuthentication = False
rfidAuthentication = False
pirAuthentication = False
doorBreach = False
parametersPassed = 0
print('################GLOBALS SET')

def readPassword():
    #reinitialize gpio
    for j in range(3):
        GPIO.setup(COL[j], GPIO.OUT)
        GPIO.output(COL[j], 1)
    for i in range(4):
        GPIO.setup(ROW[i], GPIO.IN, pull_up_down = GPIO.PUD_UP)
    for j in range(3):
            GPIO.output(COL[j], 0)
            for i in range(4):
                if GPIO.input(ROW[i]) == 0:
                    global inputPassword
                    print (MATRIX[i][j])
                    print('row is' + str(i) + 'col is' + str(j))
                    inputPassword = inputPassword + MATRIX[i][j]
                    print(MATRIX[i][j])
                    while (GPIO.input(ROW[i]) == 0):
                        pass
                        time.sleep(0.2) 
                    return (MATRIX[i][j])
                    print('debouncing')
            GPIO.output(COL[j], 1)

def checkNormalPassword(inputPassword):
    global passwordAuthentication 
    if normalPassword in inputPassword:
        print('Password matched')
        passwordAuthentication = True

def checkEmergencyPassword(inputPassword):
    if emergencyPassword in inputPassword:
        print('!!!!!!!!Emergency mode!!!!!!!!')
        sendEmergencyAlert()
        validateEmergency()
        sendEmergencyAlert()

def checkRfid():
    global rfidAuthentication       
    rfid = GPIO.input(18)
    if rfid == 0:
        rfidAuthentication = False
        pass
    elif rfid == 1:
        time.sleep(0.2)
        rfid = GPIO.input(18)
        if rfid == 1:
            print('###########RFID FINALIZED')
            rfidAuthentication = True    

def openDoor():
    print('door opened')

def closeDoor():
    print('door closed')
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("emailid@provider.com", "emailPassword")

        msg = "Intruder ALERT at house!"
        server.sendmail("emailid@provider.com", "emailid@provider.com", msg)
        server.quit()
        print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        print('ALERT SENT VIA EMAIL')
        print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    except:
        print('smtp error in sendAlert()')

def sendEmergencyAlert():
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("emailid@provider.com", "emailPassword")

        msg = "EMERGENCY EMERGENCY AT HOUSE NUMBER 10!"
        server.sendmail("emailid@provider.com", "emailid@provider.com", msg)
        server.quit()
        print('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
        print('EMERGENCY ALERT SENT VIA EMAIL')
        print('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
    except:
        print('smtp error in sendEmergencyAlert()')

def disableAlert():
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("emailid@provider.com", "emailPassword")

        msg = "killSwitch used!"
        server.sendmail("emailid@provider.com", "emailid@provider.com", msg)
        server.quit()
        print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        print('ALERT HAS BEEN DISABLED')
        print('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    except:
        print('smtp error in disableAlert()')

def killSwitch():                       #once inside the house
    global passwordAuthentication       #use global variable
    global faceAuthentication           #use global variable
    global rfidAuthentication           #use global variable
    global pirAuthentication            #use global variable
    global inputPassword                #use global variable
    global doorBreach                   #use global variable

    closeDoor()
    killSignal()
    
    passwordAuthentication = False      #reset variables
    faceAuthentication = False
    rfidAuthentication = False
    pirAuthentication = False
    doorBreach = False
    inputPassword = '0'
    disableAlert()
    os.system('clear')
    print('########')
    print('NEW ITERATION########')
    print('########')

def killSignal():
    GPIO.setup(11, GPIO.HIGH)       #kill signal to nano
    print('---------------------NANO SYNC DELAY')
    time.sleep(3)                   #sync time
    GPIO.setup(11, GPIO.LOW)
    print('---------------------NANO REACTIVATION DELAY')
    time.sleep(5)                   #nano activation time
            
    
def checkKillSwitch():
    killSwitchStatus = GPIO.input(22)
    if killSwitchStatus == 1:
        pass
        
    elif killSwitchStatus == 0:
        time.sleep(0.5)
        killSwitchStatus = GPIO.input(22)
        
        if killSwitchStatus == 0:
            print('!!!KILL SWITCH PRESSED!!!')
            GPIO.setup(11, GPIO.HIGH)     
            time.sleep(3)                 
            killSwitch()
            GPIO.setup(11, GPIO.LOW)
def displayBreach():
    for i in xrange(1,3):
        GPIO.setup(16, GPIO.HIGH)
        time.sleep(0.2)
        GPIO.setup(16, GPIO.LOW)
        time.sleep(0.2)
        print('BREACH BREACH BREACH BREACH')
    for i in xrange(1,10):
        print(' ')        

def checkDoorBreach():
    doorBreachStatus = GPIO.input(32)
    if doorBreachStatus == 0:
        pass
        
    elif doorBreachStatus == 1:
        time.sleep(0.5)
        doorBreachStatus = GPIO.input(32)
        
        if doorBreachStatus == 1:
            sendBreachAlert()
            GPIO.setup(16, GPIO.HIGH)
            time.sleep(0.2)
            GPIO.setup(16, GPIO.LOW)
            time.sleep(0.2)
            print('checking faces')
            os.system('python faceCrop.py')
            print('done checking faces')
            print('@@@@@@@@@@CAPTURING VIDEO@@@@@@@@@@')
            captureVideo()
            print('+++++++++CAPTURING VIDEO DONE +++++++++++++++++') 
            
            print('breachSleep')
            time.sleep(5)
            print('breachSLeep ENDS')
            os.system('clear')
            print('########')
            print('NEW ITERATION########')
            print('########')

def captureVideo():
    timestr = time.strftime("%Y%m%d-%H%M%S")
    fileName = timestr + '.avi'
    print (timestr)
    cap = cv2.VideoCapture(0)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(fileName,fourcc, 20.0, (640,480))

    testInput = '0'

    while(cap.isOpened()):
        ret, frame = cap.read()
        if ret==True:
            frame = cv2.flip(frame,0)
            out.write(frame)
            cv2.imshow('frame',frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            break
        killSwitchStatus = GPIO.input(22)
        if killSwitchStatus == 1:
            pass
            
        elif killSwitchStatus == 0:
            time.sleep(0.5)
            killSwitchStatus = GPIO.input(22)
            
            if killSwitchStatus == 0:
                print('!!!KILL SWITCH PRESSED!!!')
                GPIO.setup(11, GPIO.HIGH)      
                time.sleep(3)             
                killSwitch()
                break
                GPIO.setup(11, GPIO.LOW)
    cap.release()
    out.release()
    cv2.destroyAllWindows()

def sendBreachAlert():
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("emailid@provider.com", "emailPassword")

        msg = "Intruder ALERT at house!"
        server.sendmail("emailid@provider.com", "emailid@provider.com", msg)
        server.quit()
        print('ALERT ALERT ALERT ALERT')
        print('BREACH ALERT SENT VIA EMAIL')
        print('BREACH ALERT SENT VIA EMAIL')
    except:
        print('smtp error in sendBreachAlert()')

def displayEmergency():
    print('green zone notice')
    for i in xrange(1,5):
        GPIO.setup(16, GPIO.HIGH)
        time.sleep(0.5)
        GPIO.setup(16, GPIO.LOW)
        time.sleep(0.5)
def greenZoneEntry():
    GPIO.setup(16, GPIO.HIGH)
    print('green zone')
    time.sleep(5)                         
    print('green zone ends')
    GPIO.setup(16, GPIO.LOW)              
    killSwitch()
    closeDoor()

def validateEmergency():
    openDoor()
    displayEmergency()
    print('checking faces')
    os.system('python emergencyState.py')
    print('done checking faces')
    openDoor()
    greenZoneEntry()
    print('done EMERGENCY ENTRY')

def validateParameters():
    global passwordAuthentication
    global rfidAuthentication    
    parametersPassed = 0    
    if(passwordAuthentication == True):
        parametersPassed += 1
    if(rfidAuthentication == True):
        parametersPassed += 1

    if(parametersPassed >= 2):
        openDoor()
        displayEmergency()
        openDoor()
        greenZoneEntry()
        print('done validate-killing')
time.sleep(1)
print('W E L C O M E')
print('T O')
print('A R I S E')
print('########BEGIN########')

if __name__ == '__main__':
	while True:
	    #loop indefinitely
	    checkRfid()
	    checkKillSwitch()
	    readPassword()
	    checkNormalPassword(inputPassword)
	    checkEmergencyPassword(inputPassword)
	    checkDoorBreach()
	    validateParameters()