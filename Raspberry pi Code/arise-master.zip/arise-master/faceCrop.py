#!/usr/bin/python
# -*- coding: utf-8 -*-

import cv2
import os
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart


def breachFaceCropEmail(image):
    print '######################################################'
    print '@breachFaceCropEmail taking EMERGENCY snap'
    timestr = time.strftime('%Y%m%d-%H%M%S')
    print timestr
    imageName = timestr + '.jpg'
    os.system('raspistill -w 1920 -h 1080 -n -q 20 -o ' + timestr
              + '.jpg')
    facedata = 'haarcascades/haarcascade_frontalface_default.xml'
    cascade = cv2.CascadeClassifier(facedata)

    img = cv2.imread(imageName)
    print '@breachFaceCropEmail image loaded'
    minisize = (img.shape[1], img.shape[0])
    miniframe = cv2.resize(img, minisize)

    faces = cascade.detectMultiScale(miniframe)
    msg = MIMEMultipart()
    msg['Subject'] = 'BREACH AT HOUSE WAS DETECHED'
    msg['From'] = 'emailid@provider.com'
    msg['To'] = 'emailid@provider.com'
    text = MIMEText('During breach, following faces were detected')
    msg.attach(text)

    # attach base image

    face_file_name = imageName
    print 'attached-' + imageName
    img_data = open(face_file_name, 'rb').read()
    image = MIMEImage(img_data, name=os.path.basename(face_file_name))
    msg.attach(image)
    print '@breachFaceCropEmail detecting faces'
    for f in faces:
        (x, y, w, h) = [v for v in f]
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 255))

        sub_face = img[y:y + h, x:x + w]

        face_file_name = 'face_' + str(y) + '.jpg'
        cv2.imwrite(face_file_name, sub_face)

        img_data = open(face_file_name, 'rb').read()
        image = MIMEImage(img_data,
                          name=os.path.basename(face_file_name))
        msg.attach(image)
        print '@breachFaceCropEmail detection was successful, images were saved'

    try:

    # smtp part

        print '@breachFaceCropEmail compiling email'
        s = smtplib.SMTP('smtp.gmail.com', 587)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login('emailid@provider.com', 'emailPassword')
        s.sendmail('emailid@provider.com', 'emailid@provider.com',
                   msg.as_string())
        s.quit()
        print '@breachFaceCropEmail email sent'
    except:
        print 'error sending image email'
    print '@breachFaceCropEmail EXITING'
    exit()

    # cv2.imshow(image, img)

    return


if __name__ == '__main__':
    breachFaceCropEmail('faces.jpg')

    while True:
        key = cv2.waitKey(20)
        if key in [27, ord('Q'), ord('q')]:
            break
else:
    print("faceCrop.py is being imported into another module")

			