# Automated Realtime Security System (ARISE)

## Introduction
With the advent of new equipment, the house breaching capabilities of intruders  have
vastly increased. As a countermeasure, passive security systems have been implemented
by home owners and corporate offices. While these systems provide adequate security,
they fail to differentiate between potential intruders and permitted individuals. Another
area commercial systems lack in is reporting the activity of area under surveillance in real
time to the user, when the user is remotely located away from the property.

The aim of this project is to design an automated security system which leverages the
combined capabilities of available security modules and computer vision libraries. The
motivation of this project is that privacy and security have become the cornerstone of
peaceful life in urban areas, which still needs a greater level of development and tighter
integration of available modules. In this project, the status of the security system will be
reflected in email being sent to the property owner and other concerning individuals. A
Raspberry Pi will be used for handling image processing and password authentication
part of the security system. An ATmega 328 microcontroller is responsible for Radio-
frequency identity card(RFID) authentication and controlling the state of ambient lights.
The   system   will   get   information   about   human   presence   from   passive   infra-red(PIR)
module. A comprehensive storage structure has been implemented to store entry logs.

An automatic presence detection system comprised of passive infra-red sensor and one or
more   camera   modules   has   been   implemented.   The   processing   circuits   have   switching
devices for handshaking with each other through general purpose input output pins. A
display monitor displays data about the overall system status. An email-implementation
generates   alert   messages  in  case   the  system   detects   a  breach   or  potential   harm  to  the
existing setup.

## Objectives of Project
- To ensure security of house through authentication procedures
- To maintain log of accesses and breaches using computer vision and image processing
- To improve property owner’s awareness about activity in and around his/her property
##Software Dependencies

#### Language
- Python 2.7
#### Dependencies
-  OpenCV 3.0
-  RPI.GPIO

Note- Launch the project through arise.py
